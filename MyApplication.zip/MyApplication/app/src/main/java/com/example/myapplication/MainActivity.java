package com.example.myapplication;

import android.accessibilityservice.AccessibilityService;
import android.app.Activity;
import android.hardware.ConsumerIrManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    private ConsumerIrManager irManager;
    private Vibrator vibrator;
    private Handler handler = new Handler();
    private boolean isSending = false;
    private int sendingIndex = -1;

    // 红外码
    private final int[] patterns = {
            0xfe017f80, 0xfc037f80, 0xfb047f80, 0xf9067f80,
            0xf7087f80, 0xe41b7f80, 0xf30c7f80, 0xf10e7f80
    };

    // 按钮id数组
    private final int[] btnIds = {
            R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
            R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        irManager = (ConsumerIrManager) getSystemService(CONSUMER_IR_SERVICE);

        if (irManager == null || !irManager.hasIrEmitter()) {
            Toast.makeText(this, "本机不支持红外发射", Toast.LENGTH_LONG).show();
            return;
        }

        for (int i = 0; i < btnIds.length; i++) {
            final int idx = i;
            Button btn = findViewById(btnIds[i]);
            btn.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            provideHapticFeedback(v);
                            isSending = true;
                            sendingIndex = idx;
                            handler.post(sendRunnable);
                            return true;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            isSending = false;
                            sendingIndex = -1;
                            handler.removeCallbacks(sendRunnable);
                            return true;
                    }
                    return false;
                }
            });
        }
    }

    // 持续发送（每80ms发一次，可调整）
    private final Runnable sendRunnable = new Runnable() {
        @Override
        public void run() {
            if (isSending && sendingIndex >= 0) {
                sendIr(patterns[sendingIndex]);
                handler.postDelayed(this, 80); // 每80ms发送一次
            }
        }
    };
    // NEC协议编码（简单实现，部分遥控器适用）
    private int[] necEncode(int data) {
        int[] result = new int[67];
        int idx = 0;
        result[idx++] = 9000; // 9ms高电平
        result[idx++] = 4500; // 4.5ms低电平
        for (int i = 0; i < 32; i++) {
            result[idx++] = 560; // 0.56ms高
            if (((data >> i) & 1) == 1) {
                result[idx++] = 1690; // 1.69ms低
            } else {
                result[idx++] = 560; // 0.56ms低
            }
        }
        result[idx++] = 560; // 尾码
        return result;
    }
    private void provideHapticFeedback(View v) {
        v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(30); // 振动30ms
        }
    }
    private void sendIr(int pattern) {
        int freq = 38000; // 38kHz
        int[] irData = necEncode(pattern);
        irManager.transmit(freq, irData);
        // 可选：只提示一次
        // Toast.makeText(this, "发送：" + Integer.toHexString(pattern), Toast.LENGTH_SHORT).show();
    }
}
